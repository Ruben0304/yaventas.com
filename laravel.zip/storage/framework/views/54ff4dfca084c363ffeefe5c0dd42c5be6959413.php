<div>
    <main class="main">
        <section class="home-slider position-relative pt-50">
            <div class="hero-slider-1 dot-style-1 dot-style-1-position-1">
                <div class="single-hero-slider single-animation-wrap">
                    <div class="container">
                        <div class="row align-items-center slider-animated-1">
                            <div class="col-lg-5 col-md-6">
                                <div class="hero-slider-content-2">
                                    
                                    <h2 class="animated fw-900">Mochilas para niña</h2>
                                    <h1 class="animated fw-900 text-brand">En buena oferta</h1>
                                    <p class="animated">Ahorra hasta un 30%</p>
                                    <a class="animated btn btn-brush btn-brush-3" href="" wire:click="detalles"> Ir a Comprarlos </a>
                                </div>
                            </div>
                            <div class="col-lg-7 col-md-6">
                                <div class="single-slider-img single-slider-img-1">
                                    <img class="animated slider-1-1 " src="img/productos/r.png" alt="" >
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single-hero-slider single-animation-wrap">
                    <div class="container">
                        <div class="row align-items-center slider-animated-1">
                            <div class="col-lg-5 col-md-6">
                                <div class="hero-slider-content-2">
                                    
                                    <h2 class="animated fw-900">Carteras para hombre</h2>
                                    <h1 class="animated fw-900 text-7">El mejor material</h1>
                                    <p class="animated">Ahorra un 20%</p>
                                    <a class="animated btn btn-brush btn-brush-2" href="https://chat.whatsapp.com/H325FDBTtiKLi9Y9biPPpI"> Ir a Comprarlos </a>
                                </div>
                            </div>
                            <div class="col-lg-7 col-md-6">
                                <div class="single-slider-img single-slider-img-1">
                                    <img class="animated slider-1-1" src="img/productos/photo_2023-03-18_13-05-49.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>                
            </div>
            <div class="slider-arrow hero-slider-1-arrow"></div>
        </section>
        <section class="popular-categories section-padding mt-15 mb-25">
            <div class="container wow fadeIn animated">
                <h3 class="section-title mb-20"><span>Categorias</span> Populares</h3>
                <div class="carausel-6-columns-cover position-relative">
                    <div class="slider-arrow slider-arrow-2 carausel-6-columns-arrow" id="carausel-6-columns-arrows"></div>
                    <div class="carausel-6-columns" id="carausel-6-columns">
                        <div class="card-1">
                            <figure class=" img-hover-scale overflow-hidden">
                                <a href="<?php echo e(route('shoping')); ?>"><img src="img/baner.jpg" alt=""></a>
                            </figure>
                            <h5><a href="<?php echo e(route('shoping')); ?>">Alimento</a></h5>
                        </div>
                        <div class="card-1">
                            <figure class=" img-hover-scale overflow-hidden">
                                <a href="<?php echo e(route('shoping')); ?>"> <img src="img/ps55.png" alt=""></a>
                            </figure>
                            <h5><a href="<?php echo e(route('shoping')); ?>">Electronicos</a></h5>
                        </div>
                        <div class="card-1">
                            <figure class=" img-hover-scale overflow-hidden">
                                <a href="<?php echo e(route('shoping')); ?>"><img src="assets/imgs/shop/category-thumb-5.jpg" alt=""></a>
                            </figure>
                            <h5><a href="<?php echo e(route('shoping')); ?>">Zapatos</a></h5>
                        </div>
                        <div class="card-1">
                            <figure class=" img-hover-scale overflow-hidden">
                                <a href="<?php echo e(route('shoping')); ?>"><img src="assets/imgs/shop/category-thumb-1.jpg" alt=""></a>
                            </figure>
                            <h5><a href="<?php echo e(route('shoping')); ?>">Pullovers</a></h5>
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>
        
        <section class="product-tabs section-padding position-relative wow fadeIn animated">
            
            <div class="container">
                <div class="tab-header">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="nav-tab-one" data-bs-toggle="tab" data-bs-target="#tab-one" type="button" role="tab" aria-controls="tab-one" aria-selected="true">Mas vendidos</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="nav-tab-two" data-bs-toggle="tab" data-bs-target="#tab-two" type="button" role="tab" aria-controls="tab-two" aria-selected="false">Recientes</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            
                        </li>
                    </ul>
                    <a href="#" class="view-more d-none d-md-flex">View More<i class="fi-rs-angle-double-small-right"></i></a>
                </div>
                <!--End nav-tabs-->
                <div class="tab-content wow fadeIn animated" id="myTabContent">
                    <div class="tab-pane fade show active" id="tab-one" role="tabpanel" aria-labelledby="tab-one">
                        <div class="row product-grid-4">
                                

                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <?php
                                $micro=date('u')
                            ?>
                              
 
                            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6 col-6">
                                <div class="product-cart-wrap mb-30">
                                    <div class="product-img-action-wrap">
                                        <div class="product-img product-img-zoom">
                                             <a href="<?php echo e(route('detalles','id='.$producto->id.'')); ?>">
                                                
                                                <img class="default-img" src="<?php echo e($producto->foto); ?>" alt="">
                                                <img class="hover-img" src="<?php echo e($producto->foto_2); ?>" alt="">
                                            </a>
                                        </div>
                                        
                                        <div class="product-badges product-badges-position product-badges-mrg">
                                            <span class="hot">Hot</span>
                                        </div>
                                    </div>
                                    <div class="product-content-wrap">
                                        <div class="product-category">
                                            <a href="<?php echo e(route('shoping')); ?>"><?php echo e($producto->categoria->nombre); ?></a>
                                        </div>
                                        <h2><a href="product-details.html"><?php echo e($producto->nombre); ?></a></h2>
                                        <div class="rating-result" title="<?php echo e($producto->valoracion); ?>%">
                                            <span>
                                                <span><?php echo e($producto->valoracion); ?></span>
                                            </span>
                                        </div>
                                        <div class="product-price">
                                            <span>$<?php echo e($producto->preciocup); ?> </span>
                                            <span class="old-price">$245.8</span>
                                        </div>
                                        <div class="product-action-1 show">
                                           
                                            <?php if(auth()->guard()->check()): ?>
                                                
                                            
                                            <form action="<?php echo e(route('agregar_carrito')); ?>" method="POST" name="addcart<?php echo e(Auth::user()->id*324*$producto->id+50*$producto->cant*$micro*2); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="uid">
                                                <input type="hidden" value="<?php echo e($producto->id); ?>" name="pid">
                                                <input type="hidden" value="1" name="cant">
                                                
                                            </form>
                                            
                                            <a aria-label="Add To Cart" class="action-btn hover-up"  href="#" wire:click.prevent="agregar_carrito(<?php echo e($producto->id); ?>,1)"><i class="fi-rs-shopping-bag-add"></i></a>
                                            <?php else: ?>
                                            <a aria-label="Add To Cart" class="action-btn hover-up" href="<?php echo e(route('login')); ?>"><i class="fi-rs-shopping-bag-add"></i></a>
                                            <?php endif; ?>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    
                        <!--End product-grid-4-->
                    </div>
                    <!--En tab one (Featured)-->
                    <div class="tab-pane fade" id="tab-two" role="tabpanel" aria-labelledby="tab-two">
                        <div class="row product-grid-4">
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <?php
                                $micro=date('u')
                            ?>
                              
 
                            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6 col-6">
                                <div class="product-cart-wrap mb-30">
                                    <div class="product-img-action-wrap">
                                        <div class="product-img product-img-zoom">
                                             <a href="<?php echo e(route('detalles','id='.$producto->id.'')); ?>">
                                                
                                                <img class="default-img" src="<?php echo e($producto->foto); ?>" alt="">
                                                <?php if($producto->foto_2 != null): ?>
                                                <img class="hover-img" src="<?php echo e($producto->foto_2); ?>" alt="">
                                                <?php else: ?>
                                                <img class="hover-img" src="<?php echo e($producto->foto); ?>" alt=""> 
                                                <?php endif; ?>
                                                
                                            </a>
                                        </div>
                                     
                                        
                                        <div class="product-badges product-badges-position product-badges-mrg">
                                            <span class="hot">Producto nuestro</span>
                                        </div>
                                    </div>
                                    <div class="product-content-wrap">
                                        <div class="product-category">
                                            <a href="<?php echo e(route('shoping')); ?>"><?php echo e($producto->categoria->nombre); ?></a>
                                        </div>
                                        <h2><a href="product-details.html"><?php echo e($producto->nombre); ?></a></h2>
                                        <div class="rating-result" title="<?php echo e($producto->valoracion); ?>">
                                            <span>
                                                <span><?php echo e($producto->valoracion); ?></span>
                                            </span>
                                        </div>
                                        <div class="product-price">
                                            <span>$<?php echo e($producto->preciocup); ?> </span>
                                            <span class="old-price">$245.8 </span>
                                        </div>
                                        <div class="product-action-1 show">
                                           
                                            <?php if(auth()->guard()->check()): ?>
                                                
                                            
                                            <form action="<?php echo e(route('agregar_carrito')); ?>" method="POST" name="addcart<?php echo e(Auth::user()->id*324*$producto->id+50*$producto->cant*$micro*2); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="uid">
                                                <input type="hidden" value="<?php echo e($producto->id); ?>" name="pid">
                                                <input type="hidden" value="1" name="cant">
                                                
                                            </form>
                                            
                                            <a aria-label="Add To Cart" class="action-btn hover-up"  href="#" wire:click.prevent="agregar_carrito(<?php echo e($producto->id); ?>,1)"><i class="fi-rs-shopping-bag-add"></i></a>
                                            <?php else: ?>
                                            <a aria-label="Add To Cart" class="action-btn hover-up" href="<?php echo e(route('login')); ?>"><i class="fi-rs-shopping-bag-add"></i></a>
                                            <?php endif; ?>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                        <!--End product-grid-4-->
                    </div>
                    <!--En tab two (Popular)-->
                    <div class="tab-pane fade" id="tab-three" role="tabpanel" aria-labelledby="tab-three">
                        <div class="row product-grid-4">
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <?php
                                $micro=date('u')
                            ?>
                              
 
                            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6 col-6">
                                <div class="product-cart-wrap mb-30">
                                    <div class="product-img-action-wrap">
                                        <div class="product-img product-img-zoom">
                                             <a href="<?php echo e(route('detalles','id='.$producto->id.'')); ?>">
                                                
                                                <img class="default-img" src="<?php echo e($producto->foto); ?>" alt="">
                                                <img class="hover-img" src="<?php echo e($producto->foto); ?>" alt="">
                                            </a>
                                        </div>
                                        
                                        <div class="product-badges product-badges-position product-badges-mrg">
                                            <span class="hot">Hot</span>
                                        </div>
                                    </div>
                                    <div class="product-content-wrap">
                                        <div class="product-category">
                                            <a href="<?php echo e(route('shoping')); ?>"><?php echo e($producto->categoria->nombre); ?></a>
                                        </div>
                                        <h2><a href="product-details.html"><?php echo e($producto->nombre); ?></a></h2>
                                        <div class="rating-result" title="<?php echo e($producto->valoracion); ?>%">
                                            <span>
                                                <span><?php echo e($producto->valoracion); ?></span>
                                            </span>
                                        </div>
                                        <div class="product-price">
                                            <span>$<?php echo e($producto->preciocup); ?> </span>
                                            <span class="old-price">$245.8 </span>
                                        </div>
                                        <div class="product-action-1 show">
                                           
                                            <?php if(auth()->guard()->check()): ?>
                                                
                                            
                                            <form action="<?php echo e(route('agregar_carrito')); ?>" method="POST" name="addcart<?php echo e(Auth::user()->id*324*$producto->id+50*$producto->cant*$micro*2); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="uid">
                                                <input type="hidden" value="<?php echo e($producto->id); ?>" name="pid">
                                                <input type="hidden" value="1" name="cant">
                                                
                                            </form>
                                            
                                            <a aria-label="Add To Cart" class="action-btn hover-up"  href="#" wire:click.prevent="agregar_carrito(<?php echo e($producto->id); ?>,1)"><i class="fi-rs-shopping-bag-add"></i></a>
                                            <?php else: ?>
                                            <a aria-label="Add To Cart" class="action-btn hover-up" href="<?php echo e(route('login')); ?>"><i class="fi-rs-shopping-bag-add"></i></a>
                                            <?php endif; ?>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </div>
                        <!--End product-grid-4-->
                    </div>
                    <!--En tab three (New added)-->
                </div>
                <!--End tab-content-->
            </div>
        </section>
        <section class="banner-2 section-padding pb-0">
            <div class="container">
                <div class="banner-img banner-big wow fadeIn animated f-none">
                    <img src="assets/imgs/banner/banner-4.png" alt="">
                    <div class="banner-text d-md-block d-none">
                        <h4 class="mb-15 mt-40 text-brand"></h4>
                        <h1 class="fw-600 mb-20">Aqui nos hace falta disenar algo <br></h1>
                        <a href="<?php echo e(route('shoping')); ?>" class="btn">Leer mas <i class="fi-rs-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="banners mb-15">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="banner-img wow fadeIn animated">
                            <img src="assets/imgs/banner/banner-1.png" alt="">
                            <div class="banner-text">
                                <span>Smart Offer</span>
                                <h4>Save 20% on <br>Woman Bag</h4>
                                <a href="<?php echo e(route('shoping')); ?>">Shop Now <i class="fi-rs-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="banner-img wow fadeIn animated">
                            <img src="assets/imgs/banner/banner-2.png" alt="">
                            <div class="banner-text">
                                <span>Sale off</span>
                                <h4>Great Summer <br>Collection</h4>
                                <a href="<?php echo e(route('shoping')); ?>">Shop Now <i class="fi-rs-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 d-md-none d-lg-flex">
                        <div class="banner-img wow fadeIn animated  mb-sm-0">
                            <img src="assets/imgs/banner/banner-3.png" alt="">
                            <div class="banner-text">
                                <span>New Arrivals</span>
                                <h4>Shop Today’s <br>Deals & Offers</h4>
                                <a href="<?php echo e(route('shoping')); ?>">Shop Now <i class="fi-rs-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section-padding">
            <div class="container wow fadeIn animated">
                <h3 class="section-title mb-20"><span>Nuevos</span> Productos</h3>
                <div class="carausel-6-columns-cover position-relative">
                    <div class="slider-arrow slider-arrow-2 carausel-6-columns-arrow" id="carausel-6-columns-2-arrows"></div>
                    <div class="carausel-6-columns carausel-arrow-center" id="carausel-6-columns-2">
                        <div class="product-cart-wrap small hover-up">
                            
                                
                            
                            
                        
                        <!--End product-cart-wrap-2-->
                        
                        <!--End product-cart-wrap-2-->
                    </div>
                </div>
            </div>
        </section>
       
        
        
    </main>
</div>
<?php /**PATH C:\xampp2\htdocs\gustazo\resources\views/livewire/home-component.blade.php ENDPATH**/ ?>