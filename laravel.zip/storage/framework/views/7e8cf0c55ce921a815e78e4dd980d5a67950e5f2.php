<div>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('home')); ?>" rel="nofollow">Inicio</a>
                    <span></span> Detalles
                   
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="product-detail accordion-detail">
                            <div class="row mb-50">
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="detail-gallery">
                                        <span class="zoom-icon"><i class="fi-rs-search"></i></span>
                                        <!-- MAIN SLIDES -->
                                        <div class="product-image-slider">
                                            <figure class="border-radius-10" >
                                                <img src="<?php echo e($producto->foto); ?>" alt="product image" style="width: 100%, heigth: 100%">
                                            </figure>
                                            <?php if($producto->foto_2 != null): ?>
                                            <figure class="border-radius-10">
                                                <img src="<?php echo e($producto->foto_2); ?>" alt="product image">
                                            </figure>

                                             <?php if($producto->foto_3 != null): ?>
                                             <figure class="border-radius-10">
                                                <img src="<?php echo e($producto->foto_3); ?>" alt="product image">
                                            </figure>
                                             <?php endif; ?>

                                            <?php endif; ?>
                                            
                                            
                                           
                                        </div>
                                        <!-- THUMBNAILS -->
                                        <div class="slider-nav-thumbnails pl-15 pr-15" >
                                            <div><img src="<?php echo e($producto->foto); ?>" alt="product image"  ></div>
                                            <?php if($producto->foto_2 != null): ?>
                                            <div><img src="<?php echo e($producto->foto_2); ?>" alt="product image"></div>
                                            <?php endif; ?>
                                            <?php if($producto->foto_3 != null): ?>
                                            <div><img src="<?php echo e($producto->foto_3); ?>" alt="product image"></div>
                                            

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <!-- End Gallery -->
                                    <div class="social-icons single-share">
                                        <ul class="text-grey-5 d-inline-block">
                                            <li><strong class="mr-10">Comprte el producto:</strong></li>
                                            <li class="social-facebook"><a href="#"><img src="assets/imgs/theme/icons/icon-facebook.svg" alt=""></a></li>
                                            <li class="social-twitter"> <a href="#"><img src="assets/imgs/theme/icons/icon-twitter.svg" alt=""></a></li>
                                            <li class="social-instagram"><a href="#"><img src="assets/imgs/theme/icons/icon-instagram.svg" alt=""></a></li>
                                            <li class="social-linkedin"><a href="#"><img src="assets/imgs/theme/icons/icon-pinterest.svg" alt=""></a></li>
                                        </ul>
                                    </div>
                                </div>
                     
                                
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="detail-info">
                                        <h2 class="title-detail"><?php echo e($producto->nombre); ?></h2>
                                        <div class="product-detail-rating">
                                            <div class="pro-details-brand">
                                                <span> Categoria: <a href="a','categoria='.$producto->categoria->id.'')}}"><?php echo e($producto->categoria->nombre); ?></a></span>
                                            </div>
                                            
                                               
                                                
                                        </div>
                                        <div class="clearfix product-price-cover">
                                            <div class="product-price primary-color float-left">
                                                <ins><span class="text-brand">$<?php echo e($producto->preciocup); ?></span></ins>
                                                
                                            </div>
                                        </div>
                                        <div class="bt-1 border-color-1 mt-15 mb-15"></div>
                                        <div class="short-desc mb-30">
                                            <p><?php echo e($producto->descripcion); ?></p>
                                        </div>
                                        
                                        <div class="attr-detail attr-color mb-15">
                                            <strong class="mr-10">Color</strong>
                                            <ul class="list-filter color-filter">
                                                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                <li> <a href="<?php echo e(route('detalles','id='.$item->id.'')); ?>" data-color="<?php echo e($item->color); ?>"> <span class="product-color-<?php echo e($item->color); ?>" style="background-color:<?php echo e($item->color); ?>"></span></a></li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <div class="attr-detail attr-size">
                                            <strong class="mr-10">Talla</strong>
                                            <ul class="list-filter size-filter font-small">
                                                <li><a href="#">S</a></li>
                                                <li class="active"><a href="#">M</a></li>
                                                <li><a href="#">L</a></li>
                                                <li><a href="#">XL</a></li>
                                                <li><a href="#">XXL</a></li>
                                            </ul>
                                        </div> 
                                        <div class="bt-1 border-color-1 mt-30 mb-30"></div>
                                        <div class="detail-extralink">
                                            
                                            <div class="product-extra-link2">
                                                <form action="<?php echo e(route('agregar_carrito')); ?>" method="POST">
                                                    <input type="hidden" value="<?php echo e($producto->id); ?>" name="id">
                                                <button type="submit" class="button button-add-to-cart">Agregar al carrito</button>
                                            </form>
                                                <a aria-label="Add To Wishlist" class="action-btn hover-up" href="#" wire:click="renderi"><i class="fi-rs-heart"></i></a>
                                                <a aria-label="Compare" class="action-btn hover-up" href="compare.php"><i class="fi-rs-shuffle"></i></a>
                                            </div>
                                        </div>
                                        <ul class="product-meta font-xs color-grey mt-50">
                                            
                                            <li>Availability:<span class="in-stock text-success ml-5"><?php echo e($producto->stock); ?> en Stock</span></li> 
                                        </ul>
                                    </div>
                                    <!-- Detail Info -->
                                </div>
                            </div>
                            <div class="tab-style3">
                                <ul class="nav nav-tabs text-uppercase">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="Description-tab" data-bs-toggle="tab" href="#Description">Descripcion</a>
                                    </li>
                                    
                                    
                                </ul>
                                <div class="tab-content shop_info_tab entry-main-content">
                                    <div class="tab-pane fade show active" id="Description">
                                        <div class="">
                                            <p><?php echo e($producto->descripcion); ?></p>
                                            
                                            
                                            
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-lg-3 primary-sidebar sticky-sidebar">
                        <div class="row">
                            <div class="col-lg-12 col-mg-6"></div>
                            <div class="col-lg-12 col-mg-6"></div>
                        </div>
                        <div class="widget-category mb-30">
                            <h5 class="section-title style-1 mb-30 wow fadeIn animated">Categorias</h5>
                            <ul class="categories">
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('shoping')); ?>"><?php echo e($categoria->nombre); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </ul>
                        </div>
                        <!-- Fillter By Price -->
                        <div class="sidebar-widget price_range range mb-30">
                            <div class="widget-header position-relative mb-20 pb-10">
                                <h5 class="widget-title mb-10">Filtrar por precio</h5>
                                <div class="bt-1 border-color-1"></div>
                            </div>
                            <div class="price-filter">
                                <div class="price-filter-inner">
                                    <div id="slider-range"></div>
                                    <div class="price_slider_amount">
                                        <div class="label-input">
                                            <span>Rango:</span><input type="text" id="amount" name="precio" placeholder="Agrega precio">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="list-group">
                                <div class="list-group-item mb-10 mt-10">
                                    
                                    <label class="fw-900 mt-15">Condicion</label>
                                    <div class="custome-checkbox">
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="exampleCheckbox11" value="">
                                        <label class="form-check-label" for="exampleCheckbox11"><span>Nuevo ()</span></label>
                                        <br>
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="exampleCheckbox21" value="">
                                        <label class="form-check-label" for="exampleCheckbox21"><span>De Uso ()</span></label>
                                        <br>
                                      
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('shoping')); ?>" class="btn btn-sm btn-default"><i class="fi-rs-filter mr-5"></i> Filtrar</a>
                        </div>
                        <!-- Product sidebar Widget -->
                        
                        
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>
<?php /**PATH C:\xampp2\htdocs\gustazo\resources\views/livewire/detalles-component.blade.php ENDPATH**/ ?>