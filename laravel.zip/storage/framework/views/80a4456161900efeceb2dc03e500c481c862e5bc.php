
    

<div class="hero__search__form">
    <form action="<?php echo e(route('buscar')); ?>" method="GET">
        <?php echo csrf_field(); ?>
        <div class="hero__search__categories">
           Todas las Categorias
            
        </div>
        <input type="text" placeholder="Que necesitas ?" name="buscar">
        <button type="submit" class="site-btn">Buscar</button>
    </form>
</div>


<?php /**PATH C:\xampp2\htdocs\gustazo\resources\views/_search.blade.php ENDPATH**/ ?>