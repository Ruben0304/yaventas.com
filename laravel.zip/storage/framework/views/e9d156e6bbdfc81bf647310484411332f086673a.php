

    <?php if($usuario==Auth::user()->id): ?>
<script> document.location.href='./addcart?uid='.<?php echo e(Auth::user()->id); ?>.'&pid='.<?php echo e($producto); ?>.'&cant='.<?php echo e($cantidad); ?>.''</script>
  

    
   <?php else: ?>
   <?php echo e(redirect(route('home'))); ?>


<?php endif; ?>


<?php /**PATH C:\xampp2\htdocs\tualimento\resources\views/webservices/verificar_usuario.blade.php ENDPATH**/ ?>