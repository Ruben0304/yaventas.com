<div>
    <style>
        nav svg{
            height: 20px;

        }
        nav .hidden{
            display: block;
        }
    </style>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="index.html" rel="nofollow">Home</a>
                    
                    <span></span> Categorias
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                    <div class="card">
                        <div class="card-header">
Editar Categoria
                        </div>
                        <div class="card-body">
                           <form action="<?php echo e(route('actualizar_categoria')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                          <?php echo method_field('PUT'); ?>
                        <div class="mb-3 mt-3">
                            <label for="nombre" class="form-label">Nombre</label>
<input type="text" name="nombre" class="form-control" value="<?php echo e($categoria->nombre); ?>">
<input type="hidden" name="id" class="form-control" value="<?php echo e($categoria->id); ?>">
<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-danger"><?php echo e($message); ?></p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
<button type="submit" class="btn btn-primary float-end">Aceptar</button>
                           </form>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>
<?php /**PATH C:\xampp2\htdocs\gustazo\resources\views/livewire/admin/editar-categoria-component.blade.php ENDPATH**/ ?>