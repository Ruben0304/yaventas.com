
<div>
    <style>
        nav svg{
            height: 20px;

        }
        nav .hidden{
            display: block;
        }
    </style>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="index.html" rel="nofollow">Home</a>
                    
                    <span></span> Productos
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                    <div class="card">
                        <div class="card-header">
Todas los productos
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nombre</th>
                                        <th>CUP</th>
                                        <th>USD</th>
                                        <th>Stock</th>
                                        <th>Color</th>
                                        <th>Vendedor</th>
                                        <th>Categoria</th>
                                    </tr>
                                </thead>
<tbody>
    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($producto->id); ?></td>
            <td><?php echo e($producto->nombre); ?></td>
            <td><?php echo e($producto->preciocup); ?></td>
            <td><?php echo e($producto->preciousd); ?></td>
            <td><?php echo e($producto->stock); ?></td>
            <td><?php echo e($producto->color); ?></td>
            <td><?php echo e($producto->vendedor->nombre); ?></td>
            <td><?php echo e($producto->categoria->nombre); ?></td>
            <td style="display: flex; justify-content:space-between"> <a href="<?php echo e(route('admin.editar.productos','id='.$producto->id.'')); ?>"> Editar</a> <a href="" wire:click.prevent="eliminar_producto(<?php echo e($producto->id); ?>)"><i class="fi-rs-trash"></i></a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
                            </table>
<?php echo e($productos->links()); ?>

                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>
<?php /**PATH C:\xampp2\htdocs\gustazo\resources\views/livewire/admin/admin-productos-component.blade.php ENDPATH**/ ?>