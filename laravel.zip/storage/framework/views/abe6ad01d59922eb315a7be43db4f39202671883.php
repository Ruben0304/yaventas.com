<div>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('home')); ?>" rel="nofollow">Home</a>
                    <span></span> Shop
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="shop-product-fillter">
                            <div class="totall-product">
                                <p>Resultados</p>
                            </div>
                            <div class="sort-by-product-area">
                                
                                <div class="sort-by-cover">
                                    <div class="sort-by-product-wrap">
                                        <div class="sort-by">
                                            <span><i class="fi-rs-apps-sort"></i>Ordenar por:</span>
                                        </div>
                                        <div class="sort-by-dropdown-wrap">
                                            <span> Filtros <i class="fi-rs-angle-small-down"></i></span>
                                        </div>
                                    </div>
                                    <div class="sort-by-dropdown">
                                        <ul>
                                            <li><a  class="<?php echo e($orderBy=='' ? 'active': 'Default'); ?>" href="#" wire:click.prevent="cambiar_orden('Default')">Todos</a></li>
                                            <li><a class="<?php echo e($orderBy=='' ? 'active': 'Precio: Menor a Mayor'); ?>" href="#" wire:click.prevent="cambiar_orden('Precio: Menor a Mayor')">Precio: Menor a Mayor</a></li>
                                            <li><a class="<?php echo e($orderBy=='' ? 'active': 'Precio: Mayor a Menor'); ?>" href="#" wire:click.prevent="cambiar_orden('Precio: Mayor a Menor')">Precio: Mayor a Menor</a></li>
                                            <li><a class="<?php echo e($orderBy=='' ? 'active': 'Ultimos productos'); ?>" href="#" wire:click.prevent="cambiar_orden('Ultimos productos')">Más recientes</a></li>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row product-grid-3">
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-lg-4 col-md-4 col-6 col-sm-6">
                                <div class="product-cart-wrap mb-30">
                                    <div class="product-img-action-wrap">
                                        <div class="product-img product-img-zoom">
                                            <a href="<?php echo e(route('detalles','id='.$producto->id.'')); ?>">
                                                <img class="default-img" src="<?php echo e($producto->foto); ?>" alt="">
                                                
                                            </a>
                                        </div>
                                        <div class="product-action-1">
                                            
                                            
                                        </div>
                                        
                                    </div>
                                    <div class="product-content-wrap">
                                        <div class="product-category">
                                            <a href="<?php echo e(route('shoping')); ?>"><?php echo e($producto->categoria->nombre); ?></a>
                                        </div>
                                        <h2><a href="<?php echo e(route('detalles','id='.$producto->id.'')); ?>"><?php echo e($producto->nombre); ?></a></h2>
                                        <div class="rating-result" title="<?php echo e($producto->valoracion); ?>%">
                                            <span>
                                                <span><?php echo e($producto->valoracion); ?></span>
                                            </span>
                                        </div>
                                        <div class="product-price">
                                            <span>$ <?php echo e($producto->preciocup); ?> </span>
                                            
                                        </div>
                                        <div class="product-action-1 show">
                                            <?php if(auth()->guard()->check()): ?>
                                          <?php
                                              $micro=date('u')
                                          ?>  
                                            
                                            <form action="<?php echo e(route('agregar_carrito')); ?>" method="POST" name="addcart<?php echo e(Auth::user()->id*324*$producto->id+50*$producto->cant*$micro*2); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="uid">
                                                <input type="hidden" value="<?php echo e($producto->id); ?>" name="pid">
                                                <input type="hidden" value="1" name="cant">
                                                
                                            </form>
                                            <a aria-label="Add To Cart" class="action-btn hover-up" href="javascript:document.addcart<?php echo e(Auth::user()->id*324*$producto->id+50*$producto->cant*$micro*2); ?>.submit()"><i class="fi-rs-shopping-bag-add"></i></a>
                                          
                                        
                                            <?php else: ?>
                                            <a aria-label="Add To Cart" class="action-btn hover-up" href="<?php echo e(route('login')); ?>"><i class="fi-rs-shopping-bag-add"></i></a>
 
                                            <?php endif; ?>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                            
                        </div>
                        <!--pagination-->
                        <div class="pagination-area mt-15 mb-sm-5 mb-lg-0">
                            
                            <?php echo e($productos->links()); ?>

                            
                            
                            
                            
                        </div>
                    </div>
                    <div class="col-lg-3 primary-sidebar sticky-sidebar">
                        <div class="row">
                            <div class="col-lg-12 col-mg-6"></div>
                            <div class="col-lg-12 col-mg-6"></div>
                        </div>
                        <div class="widget-category mb-30">
                            <h5 class="section-title style-1 mb-30 wow fadeIn animated">Categorias</h5>
                            <ul class="categories">
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('shoping')); ?>"><?php echo e($categoria->nombre); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </ul>
                        </div>
                        <!-- Fillter By Price -->
                        <div class="sidebar-widget price_range range mb-30">
                            <div class="widget-header position-relative mb-20 pb-10">
                                <h5 class="widget-title mb-10">Filtrar por precio</h5>
                                <div class="bt-1 border-color-1"></div>
                            </div>
                            <div class="price-filter">
                                <div class="price-filter-inner">
                                    <div id="slider-range" wire:ignore></div>
                                    <div class="price_slider_amount">
                                        <div class="label-input">
                                            <span>Rango:</span> <span class="text-info">$<?php echo e($minimo); ?></span> - <span class="text-info">$<?php echo e($maximo); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            
                        </div>
                        <!-- Product sidebar Widget -->
                        <div class="sidebar-widget product-sidebar  mb-30 p-30 bg-grey border-radius-10">
                            <div class="widget-header position-relative mb-20 pb-10">
                                <h5 class="widget-title mb-10">Nuevos productos</h5>
                                <div class="bt-1 border-color-1"></div>
                            </div>
                            <?php $__currentLoopData = $productos->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            
                            <div class="single-post clearfix">
                                <div class="image">
                                    <img src="<?php echo e($producto->foto); ?>" alt="#">
                                </div>
                                <div class="content pt-10">
                                    <h5><a href="<?php echo e(route('detalles','id='.$producto->id.'')); ?>"><?php echo e($producto->nombre); ?></a></h5>
                                    <p class="price mb-0 mt-5">$<?php echo e($producto->preciocup); ?></p>
                                    <div class="product-rate">
                                        <div class="product-rating" style="width:90%"></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
var sliderrange = $('#slider-range');
var amountprice = $('#amount');
$(function() {
    sliderrange.slider({
        range: true,
        min: 0,
        max: 5000,
        values: [0, 5000],
        slide: function(event, ui) {
            // 
            window.livewire.find('<?php echo e($_instance->id); ?>').set('minimo',ui.values[0]);
            window.livewire.find('<?php echo e($_instance->id); ?>').set('maximo',ui.values[1]);
        }
    });
}); 
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp2\htdocs\gustazo\resources\views/livewire/comprar-component.blade.php ENDPATH**/ ?>