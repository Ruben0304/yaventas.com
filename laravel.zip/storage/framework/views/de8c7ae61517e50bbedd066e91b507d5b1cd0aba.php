    
    <?php $__env->startSection('contenido'); ?>
    

<section class="hero-normal">
      
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="hero__categories">
                    <div class="hero__categories__all">
                        <i class="fa fa-bars"></i>
                        <span>Categorias</span>
                    </div>
                    <ul>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        
                        <li><a href="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
            <div class="col-lg-9">
                <div class="hero__search">
                    </ul>
                     <?php echo $__env->make('_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="hero__search__phone">
                        <div class="hero__search__phone__icon">
                            <i class="fa fa-whatsapp"></i>
                        </div>
                        <div class="hero__search__phone__text">
                            <h5>+1 7865926593</h5>
                            <span>Atenderemos Enseguida</span>
                        </div>
                    </div>
                </div>
                <div class="hero__item set-bg" data-setbg="" id="youtube">
                    <iframe width="100%" height="98%" style="margin-bottom: 2%; border:none;"
                    src="https://www.youtube.com/embed/VldpThb0SY4">
                    </iframe> 
                    
                </div>
            </div>
            </div>
        </div>
    </div>
</section>
<!-- Hero Section End -->

    <!-- Categories Section Begin -->
    
        
   
    <section class="categories">
        <div class="container">
            <div class="row">
                <div class="categories__slider owl-carousel">
                    
                 
             
           
                 <div class="col-lg-3" >
                    <div class="categories__item set-bg" data-setbg="img/mangohabana.jpg">
                        
                        
                  <h5><a href="http://"> Ropa</a></h5>
                    </div>
                </div>
               
                <div class="col-lg-3" >
                    <div class="categories__item set-bg" data-setbg="img/baner.jpg">
                        
                        
                  <h5><a href="http://"> Alimentos</a></h5>
                    </div>
                </div>
                <div class="col-lg-3" >
                    <div class="categories__item set-bg" data-setbg="img/meta_quest_2.png">
                        
                        
                  <h5><a href="http://"> Electronicos</a></h5>
                    </div>
                </div>
                 
                    
                    
                </div>
            </div>
        </div>
    </section>
    
    <!-- Categories Section End -->
   
    
    
    <!-- Featured Section Begin -->
    <section class="featured spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Productos Destacados</h2>
                    </div>
                    <div class="featured__controls">
                        <ul>
                            <li class="active" data-filter="*">Todos</li>
                            <li data-filter=".oranges">Carnes</li>
                           
                            <li data-filter=".vegetables">Vegetables</li>
                           
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row featured__filter">
                <?php $__currentLoopData = $producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-sm-6 mix oranges fresh-meat" id="latestitem">
                  
             <div style="display: none">     <?php echo e($micro=date('u')); ?></div> 
             <?php if(auth()->guard()->check()): ?>
                 
             
                   <form action="<?php echo e(route('agregar_carrito')); ?>" method="POST" name="addcart<?php echo e(Auth::user()->id*324*$item->id+50*$item->cant*$micro*2); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="uid">
                    <input type="hidden" value="<?php echo e($item->id); ?>" name="pid">
                    <input type="hidden" value="1" name="cant">
                    <?php endif; ?>
                </form>
                
                   <div class="featured__item" >
                   <div class="featured__item__pic set-bg " data-setbg="<?php echo e($item['foto']); ?>"  >
                            <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="<?php echo e(route('detalles',''.$item['id'].'')); ?>"><i class="fa fa-info-circle"></i></a></li>
                                <?php if(auth()->guard()->check()): ?>
                             
                                <li><a href="javascript:document.addcart<?php echo e(Auth::user()->id*324*$item->id+50*$item->cant*$micro*2); ?>.submit()"><i class="fa fa-shopping-cart"></i></a></li>
                                <?php else: ?>
                                <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                <?php endif; ?>
                                
                            </ul>
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="<?php echo e(route('detalles',''.$item['id'].'')); ?>"><?php echo e($item['nombre']); ?></a></h6>
                            <h5>$<?php echo e($item['precio'.$_COOKIE['moneda'].'']); ?></h5>
                        </div>
                    </div>
                </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </section>
    <!-- Featured Section End -->
    <section class="featured spad" style="padding-top: 10px">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
    <div class="product__discount">
        <div class="section-title product__discount__title" style="text-align: center">
            <h2>En Oferta</h2>
        </div>
        <div class="row">
            <div class="product__discount__slider owl-carousel">
                <?php $__currentLoopData = $oferta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php
     $antes=$item->producto['precio'.$_COOKIE['moneda'].''];
     $despues=$item['precio'.$_COOKIE['moneda'].''];
 ?>
                <div class="col-lg-4">
                    <div class="product__discount__item" >
                        <div class="product__discount__item__pic set-bg"
                            data-setbg="<?php echo e($item->producto->foto); ?>">
                            <div class="product__discount__percent">-<?php echo e(intval(($antes-$despues)*100/$antes)); ?>%</div>
                            <div class="product__discount__fecha" >Quedan <?php echo e(date_diff(date_create(date('Y-m-d')), date_create($item->fecha_final))->d); ?> días </div>
                            <ul class="product__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                        </div>
                        <div class="product__discount__item__text">
                            
                            <h5><a href="#"><?php echo e($item->producto->nombre); ?></a></h5>
                            <div class="product__item__price">$<?php echo e($item['precio'.$_COOKIE['moneda'].'']); ?> <span>$<?php echo e($item->producto['precio'.$_COOKIE['moneda'].'']); ?></span></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    </div>
</div>
</section>
    <!-- Banner Begin -->
    
    <!-- Latest Product Section End -->

    <!-- Blog Section Begin -->
    
    <!-- Blog Section End -->

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\gustazo\resources\views/home.blade.php ENDPATH**/ ?>