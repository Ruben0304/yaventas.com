<section class="hero-normal">
      
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="hero__categories">
                    <div class="hero__categories__all">
                        <i class="fa fa-bars"></i>
                        <span>Categorias</span>
                    </div>
                    <ul>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        
                        <li><a href="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></a></li>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
            <div class="col-lg-9">
                <div class="hero__search">
                    </ul>
                     <div class="hero__search__form">
                        <form action="#">
                            <div class="hero__search__categories">
                                Todas las Categorias
                                <span class="arrow_carrot-down"></span>
                            </div>
                            <input type="text" placeholder="What do yo u need?">
                            <button type="submit" class="site-btn">Buscar</button>
                        </form>
                    </div>
                    <div class="hero__search__phone">
                        <div class="hero__search__phone__icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="hero__search__phone__text">
                            <h5>+1 7865926593</h5>
                            <span>Atenderemos lo antes posible</span>
                        </div>
                    </div>
                </div>
               
            </div>
        </div>
    </div>
</section>
<!-- Hero Section End --><?php /**PATH C:\xampp2\htdocs\tualimento\resources\views/categorias.blade.php ENDPATH**/ ?>