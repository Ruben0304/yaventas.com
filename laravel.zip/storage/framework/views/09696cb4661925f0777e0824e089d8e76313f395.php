
<?php $__env->startSection('contenido'); ?>
    

<?php if(isset($error)): ?>
<?php if($error=="no pertenece a vendedor"): ?>

<script>alert("El producto no le pertenece. Intente introducir nuevamente el Id o contacte con nosotros.")</script>
<?php endif; ?>

    
<?php endif; ?>

<form action="<?php echo e(route('eliminando_producto')); ?>" method="POST" >
   <?php echo csrf_field(); ?>
   <?php echo method_field('DELETE'); ?>
     <div class="formulario">
     
    <div class="form-group">
         <label for="example-text-input" class="form-control-label">Id del producto</label>
         <input class="form-control" type="text"  name="id" required>
     </div>
     </div>

    
     
     <button type="submit" class="btn bg-gradient-success" onclick="return  confirm('Esta seguro/a de que desea eliminar el producto')">Eliminar</button>
 
 </div>
 </div>
 
 </form>

 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\gustazo\resources\views/admin/eliminar_producto.blade.php ENDPATH**/ ?>