<?php $__env->startSection('contenido'); ?>
    

    <!-- Hero Section Begin -->
    <section class="hero hero-normal">
       
      
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="hero__categories">
                        <div class="hero__categories__all">
                            <i class="fa fa-bars"></i>
                            <span>Categorias</span>
                        </div>
                        <ul>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            
                            <li><a href="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>
                </div>
                <div class="col-lg-9">
                    <div class="hero__search">
                        </ul>
                        <?php echo $__env->make('_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="hero__search__phone">
                            <div class="hero__search__phone__icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="hero__search__phone__text">
                                <h5>+1 7865926593</h5>
                                <span>Atenderemos Enseguida</span>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

   

    <!-- Shoping Cart Section Begin -->
    <section class="shoping-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="shoping__cart__table">
                        <table>
                            <thead>
                                <tr>
                                    <th class="shoping__product">Productos</th>
                                    <th>Precio</th>
                                    <th>Cantidad</th>
                                    <th>Total</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <?php if(auth()->guard()->check()): ?>
                                    <?php $carro= $carrito->where('id_user',Auth::user()->id)?> 
                                    <?php if($carro->first()==null): ?>
                                    <?php $subtotal=0 ?> 
                                   
                                     <?php else: ?>
                                    <?php $__currentLoopData = $carro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   
                                        
                                    
                                        <form action=" <?php echo e(route('quitar_carrito')); ?> " name="quitarcarrito<?php echo e(2*34+345*$item->id_user*$item->id); ?>" method="POST"> 
                                         <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($item->id); ?>" name="id">

                                        </form>
                                        <form action=" <?php echo e(route('sumar_carrito')); ?> " name="sumarcarrito<?php echo e(2*34+345*$item->id_user*$item->id); ?>" method="POST"> 
                                            <?php echo csrf_field(); ?>
                                               <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
   
                                           </form>
                                           <form action=" <?php echo e(route('restar_carrito')); ?> " name="restarcarrito<?php echo e(2*34+345*$item->id_user*$item->id); ?>" method="POST"> 
                                            <?php echo csrf_field(); ?>
                                               <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
   
                                           </form>
                                   
                                    <td class="shoping__cart__item" style="width: 630px;" >
                                        <img src="<?php echo e($item->producto->foto); ?>" alt="" style="max-width: 100%; width: 110px" >
                                        <h5><?php echo e($item->producto->nombre); ?></h5>
                                    </td>
                                    <td class="shoping__cart__price">
                                       $ <?php echo e($item->producto['precio'.$_COOKIE['moneda'].'']); ?> 
                                    </td>
                                    <td class="shoping__cart__quantity">
                                        <div class="quantity">
                                            <div class="pro-qty">
                                              <a href="javascript:document.restarcarrito<?php echo e(2*34+345*$item->id_user*$item->id); ?>.submit()"> <span class="dec qtybtn">-</span></a> 
                                                <input type="text" value=<?php echo e($item->cantidad); ?>>
                                                <a href="javascript:document.sumarcarrito<?php echo e(2*34+345*$item->id_user*$item->id); ?>.submit()"> <span class="inc qtybtn">+</span></a>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="shoping__cart__total">
                                       $ <?php echo e($item->producto['precio'.$_COOKIE['moneda'].'']*$item->cantidad); ?>

                                    </td>
                                   <td class="shoping__cart__item__close">
                                    <a href="javascript:document.quitarcarrito<?php echo e(2*34+345*$item->id_user*$item->id); ?>.submit()">  <span class="icon_close"></span></a> 
                                    </td>
                                </tr>
                               
                               
                                
                               
                              
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                                

                                <?php if($carro->count()==1): ?>
                                <div style="display: none">  <?php echo e($subtotal=($item->producto['precio'.$_COOKIE['moneda'].'']*$item->cantidad)); ?>  </div>
                                  <?php else: ?>
                                  <div style="display: none"> <?php echo e($subtotal=($carro['0']->producto['precio'.$_COOKIE['moneda'].'']*$carro['0']->cantidad)); ?> </div>
                                  <?php for($i = 1; $i < $carro->count(); $i++): ?>
                                  
                                  <div style="display: none"> <?php echo e($subtotal+=($carro[$i]->producto['precio'.$_COOKIE['moneda'].'']*$carro[$i]->cantidad)); ?> </div>
                                  
                                  <?php endfor; ?>
                                  <?php endif; ?>
                                  <?php endif; ?>
                                <?php endif; ?>
                                <tr>

                                    
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row">
                
                <div class="col-lg-6">
                    <div class="shoping__continue">
                        <div class="shoping__discount">
                            <h5>Descuentos</h5>
                            <form action="#">
                                <input type="text" placeholder="Enter your coupon code">
                                <button type="submit" class="site-btn">Aplicar Cupon</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    
                    <div class="shoping__checkout">
                        <form action="<?php echo e(route('caja')); ?>" method="POST" name="ir_a_comprar">
                         <input type="hidden" name="uid" value="<?php echo e(Auth::user()->id); ?>">
                         
                        </form>
                        <h5>Este sería el precio</h5>
                        <ul>
                            
                           
                            
                        
                        <li>Subtotal <span>$ <?php echo e($subtotal); ?></span></li>
                       
                            <li>Total <span>$ <?php echo e($subtotal); ?></span></li>
                        </ul>
                        <a href="<?php echo e(route('caja')); ?>" class="primary-btn">  Me sirve  <i class="fa fa-thumbs-o-up"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Shoping Cart Section End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\gustazo\resources\views/carrito.blade.php ENDPATH**/ ?>