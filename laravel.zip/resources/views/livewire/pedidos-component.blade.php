<div>
   
    <section class="pedidos" style="height: 700px; padding:20px; margin-left:30px; margin-right:30px">
     <iframe src="http://127.0.0.1:8000/tabla" frameborder="0" width="100%" height="100%"></iframe> 

</section>
</div>
