<style>
    .logito{
        width: 150px;
        margin-left: 45%
    }
    @media (max-width: 640px){
    .logito{
        width: 30%;
        margin-left: 35%
    }
    
}
</style>

<x-app-layout>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="index.html" rel="nofollow">Inicio</a>                    
                    <span></span> Entrar
                </div>
            </div>
        </div>
        <section class="pt-150 pb-150">
            <div class="container">
                <img src="img/profile.gif" alt="" class="logito" >
                <div class="row">
                    <div class="col-lg-10 m-auto">
                        <div class="row" style="justify-content: center;">
                            <div class="col-lg-5">
                                <div class="login_wrap widget-taber-content p-30 background-white border-radius-10 mb-md-5 mb-lg-0 mb-sm-5">
                                    <div class="padding_eight_all bg-white">
                                        <div class="heading_s1">
                                            <h3 class="mb-30">Entrar</h3>
                                        </div>
                                        <form method="post" action="{{route('login')}}">
                                            @csrf
                                            <div class="form-group">
                                                <input type="text" required="" name="email" placeholder="Correo Electronico" :value="old('email')" required autofocus>
                                                <x-input-error :messages="$errors->get('email')" class="mt-2" />
                                            </div>
                                            <div class="form-group">
                                                <input required="" type="password" name="password" placeholder="Contraseña" required autocomplete="current-password">
                                                <x-input-error :messages="$errors->get('password')" class="mt-2" />
                                            </div>
                                            <div class="login_footer form-group">
                                                <div class="chek-form">
                                                    <div class="custome-checkbox">
                                                        <input class="form-check-input" type="checkbox" name="remember" id="exampleCheckbox1" value="">
                                                        <label class="form-check-label" for="exampleCheckbox1"><span>Recordarme</span></label>
                                                    </div>
                                                </div>
                                                {{-- <a class="text-muted" href="{{route('password.request')}}">Olvidaste contraseña?</a> --}}
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-fill-out btn-block hover-up" name="login">Entrar</button>
                                            </div>
                                        </form>
                                        
                                    </div>
                                    <a href="{{route('glogin')}}" style=" display: grid;
        justify-content: center;
        margin-top: 50px;
        height: 45px;
        background-color: #dae0e2d5;
        width: 15%;
        border-radius: 13px;
        padding: 8px;
        font-weight: bold;
        margin-left: 15%;">
      
      <span style="  margin-top: 3px; width:100%" ><img src="https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg" alt="" style=""></i></span>
        </a>
                                </div>
                            </div>
                            <div class="col-lg-1"></div>
                            {{-- <div class="col-lg-6">
                               <img src="assets/imgs/login.png">
                            </div> --}}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>


</x-app-layout>



