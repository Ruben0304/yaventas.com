<?php

namespace App\Http\Controllers;
use App\Models\Ordene;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PagosController extends Controller
{
    public function pagar_con_qvapay(Request $request){
        $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://qvapay.com/api/v1/create_invoice',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>'{
        "app_id": "'.env('qvapay_id').'",
        "app_secret": "'.env('qvapay_secret').'",
        "amount": "'.$request->total.'",
        "description": "Comprar con Qvapay orden",
        "remote_id": "QVA004",
        "signed": 1
      }',
        CURLOPT_HTTPHEADER => array(
          
          'Content-Type: application/json'
        ),
      ));
      
      $response = curl_exec($curl);
      $data=json_decode($response,true);
      
          
          $signedUrl=$data["signedUrl"];
    //       $transation_uuid=$data["transation_uuid"];
           
    //       curl_close($curl);
      return redirect($signedUrl);
      
      }
      

      public function confirmar_qvapay(Request $request){
        $appid=env('qvapay_id');
        $appsecret=env('qvapay_secret');
        
        
        $transaction_uuid=$request->transaction_uuid;
 
       

        
        

// $curl = curl_init();

// curl_setopt_array($curl, array(
//   CURLOPT_URL => 'https://qvapay.com/api/',
//   CURLOPT_RETURNTRANSFER => true,
//   CURLOPT_ENCODING => '',
//   CURLOPT_MAXREDIRS => 10,
//   CURLOPT_TIMEOUT => 0,
//   CURLOPT_FOLLOWLOCATION => true,
//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//   CURLOPT_CUSTOMREQUEST => 'GET',
//   CURLOPT_POSTFIELDS =>'{
//     "app_id": "'.env('qvapay_id').'",
//     "app_secret": "'.env('qvapay_secret').'",
//     "transaction_uuid": "'.$transaction_uuid.'"
//   }',
//   CURLOPT_HTTPHEADER => array(
//     'Accept: application/json'
//   ),
// ));

// $response = curl_exec($curl);

// curl_close($curl);

// $data=json_decode($response,true);
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://qvapay.com/api/v1/transactions/'.$transaction_uuid.'?app_id='.$appid.'&app_secret='.$appsecret.'',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_HTTPHEADER => array(
    
    'Content-Type: application/json'
  ),
));

$response = curl_exec($curl);

$data=json_decode($response,true);

        if ($data==null) {
          return 'Error orden no encontrada';
        }
else {
  

$appidpago =env("qvapay_id_pagos");
$idapp=$data["app_id"];
$status=$data["status"];
$amount=$data["amount"];
$username=$data["paid_by"]["username"];
$name=$data["paid_by"]["name"];
$lastname=$data["paid_by"]["lastname"];
$appuser=$data["owner"]["username"];
curl_close($curl);

$verificar_uuid=Ordene::where('transaction_uuid',$transaction_uuid)->get();
if ($verificar_uuid->count()>0) {
 return "Error: Esta orden ya ha sido acreditada";
}
else{
if ($status=="paid" && $idapp=$appidpago ) {
    Ordene::create([
          
      
        'id_user' => Auth::user()->id,
        'total' =>  $amount,
        'subtotal' => $amount,
        'transaction_uuid' => $transaction_uuid,
        'usuario_remoto' => $username,
        'metodopago' => 'qvapay'
        
]);
return redirect(route('home')) ;
}else {
  return 'Orden no pagada o incorrecta';
}

// return redirect(route('home'));

}
}
}
}

