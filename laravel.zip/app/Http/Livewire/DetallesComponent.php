<?php

namespace App\Http\Livewire;

use App\Models\Carrito;
use App\Models\Categoria;
use App\Models\Producto;
use Illuminate\Http\Request;
use Livewire\Component;

class DetallesComponent extends Component
{
    public function renderi()
    {
        return redirect(route('home'));
    }
    public function render(Request $request)
    {
        $producto=Producto::find($request->id);
       $productos=Producto::where('nombre',$producto->nombre)->get();
        
        return view('livewire.detalles-component',[
            'producto'=>$producto,
            'productos'=>$productos,
            'valoracion'=>$producto->valoracion,
           
            
            'categorias'=>Categoria::all()
        ]);
    }
}
