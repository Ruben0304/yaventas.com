<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Carrito;
use Illuminate\Support\Facades\Auth;

class CajaComponent extends Component
{
    public function render()
    {
        $carrito=Carrito::all();
        return view('livewire.caja-component',[
            'carrito' =>$carrito
        ]);
    }
}
