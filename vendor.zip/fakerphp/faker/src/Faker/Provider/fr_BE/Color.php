<?php

namespace Faker\Provider\fr_BE;

class Color extends \Faker\Provider\fr_FR\Color
{
}
